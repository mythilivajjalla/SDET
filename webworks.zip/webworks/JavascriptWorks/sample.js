
function fnCallme(){
alert("Hi i am from external file")
}
function fnCallme1(){
alert("Hi i am from external file again")
}