package Hareesh;

public class FourthProgram {
	public static void main(String[] args) {
		
		int number = Integer.parseInt(args[0]);
		int count,factorial;
		factorial=1;
				for (count=1;count<=number;count=count+1)
					factorial=count*factorial;
					System.out.println("factorial is " +factorial);
		            System.out.println("Done !");
	}

}
