package Hareesh;

public class SecondProg {
	public static void main(String[] args) {
		int var1;
		int var2;
		var1=1000;
				
				System.out.println("value of var2 =" + var1/2 );
				System.out.print("value of var1 =" + var1);
		
	}

}
