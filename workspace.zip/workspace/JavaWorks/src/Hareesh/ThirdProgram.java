package Hareesh;

public class ThirdProgram {
	public static void main(String[] args) {
		int x, y;
		double z,i;
		x=100;
		y=2;
		z=12.3;
		
				System.out.println("value of i= " + (x/y));
	}

}
