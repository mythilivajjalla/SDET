package com.fannie;

public class Audi extends Car {
	
	public Audi() {
		// TODO Auto-generated constructor stub
		System.out.println("Audi Constructed");
	}

	public void view(){
		System.out.println("audi has rear view..");
	}
}
