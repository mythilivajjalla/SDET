package com.fannie;

public class Car extends Vehicle {
	
	public Car() {
		// TODO Auto-generated constructor stub
		System.out.println("Car");
	}
	
	public void steering(){
		System.out.println("Car has steering");
	}
	
	public void fuelCapacity(int capacity){
		System.out.println("Car Capacity " + capacity);
	}

}
