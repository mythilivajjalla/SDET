package com.fannie;

public class Ford extends Car {
	
	public Ford() {
		// TODO Auto-generated constructor stub
		System.out.println("Ford Constructed");
	}
   
	 public void abs(){
		 System.out.println("Ford has ABS...");
	 }

	@Override
	public void move() {
		// TODO Auto-generated method stub
		super.move();
		System.out.println("Ford is moving..");
	}
	 
	 
}
