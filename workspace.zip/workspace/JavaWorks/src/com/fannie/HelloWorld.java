package com.fannie;

public class HelloWorld {
	
	//main ctrl space enter
    public static void main(String[] args) {
		System.out.println("Hello world from java");
	}
		
	}
	
	//public makes this visible to os
	//static means the method is visible to class
    //void means the method has no return value
   //combination of all three is seen in the Main method


