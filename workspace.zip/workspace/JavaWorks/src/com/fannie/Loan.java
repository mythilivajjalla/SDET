package com.fannie;

//class that doestn have a main is called reusable component
//is called bean class
//a bean class shall have private variables
//public getters and setters
//default constructor ( if you dont create then compiler will create at the time of compilations)
public class Loan {
	private int lId;
	private double loanAmount;
	private double rateOfInterest;
	private String borrowerName;

	public int getlId() {
		return lId;
	}

	public void setlId(int lId) {
		this.lId = lId;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		if (loanAmount < 10000) {
			System.out.println("sorry loan cannot be processed ");
			this.loanAmount = 10000;
		} else {

			this.loanAmount = loanAmount;
		}
	}

	public double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		if(borrowerName.length()<5){
			System.out.println("Sorry Name cannot be less than 5 chars");
			this.borrowerName = "Non Name";
		}else{
		this.borrowerName = borrowerName;
	}
	} 

	// setters and getters

}
