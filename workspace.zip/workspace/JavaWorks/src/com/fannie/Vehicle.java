package com.fannie;

public class Vehicle {
	
	public Vehicle() {
		// TODO Auto-generated constructor stub
		System.out.println("Vehicle Created");
	}
	public void move(){
		System.out.println("All Vehicle Move...");
	}
	public void brake(){
		System.out.println("Vehicle applied Break");
	
	}

}
