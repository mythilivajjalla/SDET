package com.fannie.day2;

public interface BankLoan {
     void loanAmount(int amount);
     void repay(int amount);
     void foreClosure();
}
