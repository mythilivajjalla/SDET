package com.fannie.day2;

class Car{}

public class CarLoan extends Car implements BankLoan {

	@Override
	public void loanAmount(int amount) {
		System.out.println("Loan Amount is " + amount);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void repay(int amount) {
		// TODO Auto-generated method stub
		System.out.println("Loan Reyap is " + amount);
		
	}

	@Override
	public void foreClosure() {
		// TODO Auto-generated method stub
		System.out.println("You opted for ForeClousre");
		
	}

}
