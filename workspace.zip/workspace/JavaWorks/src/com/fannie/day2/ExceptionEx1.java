package com.fannie.day2;

public class ExceptionEx1 {
	public static void main(String[] args) {
		try{
		
		try{
		int arr[] = new int[-4];
		}catch (NegativeArraySizeException NASE){
		System.out.println("cannot have a negative size array");
		}
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		int res = num1 / num2 ;
		
		System.out.println("Res " + res);
		}catch(NumberFormatException e){
			System.out.println("Hey Please dont enter chars");
		}catch(ArithmeticException ae){
			System.out.println("Please dont divide by zero");
			
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Enter all the params");
		}catch(Exception e){
			System.out.println("Generic exception contact support");
		}
		System.out.println("I am some business logic....");
	}

}
