package com.fannie.day2;

public class ExceptionEx2 {
	public static void main(String[] args) {
		try {
			System.out.println("Connect to DB");
			return;
			
		}catch (Exception e){
			System.out.println("Oh Exception caught " +e);
		}finally{
			System.out.println("Close to db happens here..");
		}
		
		System.out.println("i am other code in the world...");
	}

}
