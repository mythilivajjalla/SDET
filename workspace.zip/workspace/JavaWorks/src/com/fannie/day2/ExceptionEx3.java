package com.fannie.day2;

import javax.management.RuntimeErrorException;

public class ExceptionEx3 {
	
	public static void checkCreditScore(int cs, String name){
		if (cs < 400){
			//throw an exception
			throw new RuntimeErrorException(null, "sorry it cannot be processed, MR/Ms/Mrs :" + name);
		
		}else{
            System.out.println("we are good to go, Mr/Ms/Mrs  :" + name);
		}
	}
	
	public static void main(String[] args) {
		try{
		checkCreditScore(344, "Harry");
		}catch(RuntimeException re){
			System.out.println(re.getMessage());
			
			//re.printStackTrace();
		}
		
		System.out.println("Some business works here..");
	}

}
