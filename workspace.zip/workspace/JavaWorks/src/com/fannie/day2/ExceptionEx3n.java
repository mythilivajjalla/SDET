package com.fannie.day2;

import java.io.IOError;
import java.io.IOException;

import javax.management.RuntimeErrorException;

public class ExceptionEx3n {
	
	public static void checkCreditScore(int cs, String name){
		if (cs < 400){
			//throw an exception
			throw new RuntimeErrorException(null, "sorry it cannot be processed, MR/Ms/Mrs :" + name);
		
	
		} if(cs >= 400 && cs < 500){
			
			try{
			throw new IOException ("You are not good now, try after 3 months, Mr/Ms/Mrs  : " +name);
		}catch IOException{} Finally
	}
	
	public static void main(String[] args) {
		try{
		checkCreditScore(344, "Harry");
		}catch(RuntimeException re){
			System.out.println(re.getMessage());
			
			//re.printStackTrace();
		}
		
		System.out.println("Some business works here..");
	}

}
