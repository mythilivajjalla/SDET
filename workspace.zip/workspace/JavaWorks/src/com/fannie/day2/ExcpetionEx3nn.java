package com.fannie.day2;

import java.io.IOException;

import javax.management.RuntimeErrorException;

public class ExcpetionEx3nn {
	
	public static void validateName(String name)
	throws Exception{
		if(name.length() < 5){
			throw new Exception("sorry name cannot be less than 5 chars");
			
		}
	}
	
	public static void checkCreditScore(int cs, String name)
		throws IOException, Exception {
		try{	
		validateName(name);
		}catch (Exception e) {
			throw new Exception("Sorry check of credit score not possible",  e);
		}
	
		if (cs < 400){
			//throw an exception
			throw new RuntimeErrorException ( null, "sorry it cannot be processed, MR/Ms/Mrs :" + name);
		
	
		} if(cs >= 400 && cs < 500){
			
			
			throw new IOException ("You are not good now, try after 3 months, Mr/Ms/Mrs  : " +name);
		}else{
			System.out.println("we are good ");
		}
	}
	
	public static void main(String[] args) {
		try{
		checkCreditScore(344, "Harry");
		}catch(IOException e){
				
			e.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
