package com.fannie.day2;

public class PersonSorterTemplate {
	
	public static void sortOnNameAsc(Person[] pers) {
		
	}

}
