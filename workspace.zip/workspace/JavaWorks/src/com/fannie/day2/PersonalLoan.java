package com.fannie.day2;

public class PersonalLoan implements BankLoan {

	@Override
	public void loanAmount(int amount) {
		// TODO Auto-generated method stub
		System.out.println("Loan Amount is " + amount);
		
	}

	@Override
	public void repay(int amount) {
		// TODO Auto-generated method stub
		System.out.println("Repay is " + amount);
		
	}

	@Override
	public void foreClosure() {
		// TODO Auto-generated method stub
		System.out.println("You opted for ForeClousre");
		
	}

}
