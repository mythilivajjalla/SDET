package com.fannie.day2;

import java.util.Arrays;

public class SorterNumber {
	public static void main(String[] args) {
		int [] nums = { 23,33,56,1243,8,9,555,32,789};
		
		for(int temp : nums){
			System.out.println(temp);
		}
		
		Arrays.sort(nums);
		System.out.println("......................");
		
		for(int temp : nums){
			System.out.println(temp);
		}
	}

}
