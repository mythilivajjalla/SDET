package com.fannie.day2;

public class StaticEx1 {
	
	//when we say as static to access this method
	//creating an object is not required and this method
	//is available by reference only not by
	//instatiation doing so will not even create an object
	//all statics are signleton (one instance only)
	
	public int add(int num1, int num2) {
		return num1 + num2;
	}
	public static void main(String[] args) {
		
		StaticEx1 s = new StaticEx1();
		int res = s.add(10, 20);
		System.out.println("Resule " +res);
		
	}

}
