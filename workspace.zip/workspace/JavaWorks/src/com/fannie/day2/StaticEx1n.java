package com.fannie.day2;

public class StaticEx1n {
	
	//when we say as static to access this method
	//creating an object is not required and this method
	//is available by reference only not by
	//instatiation doing so will not even create an object
	//all statics are signleton (one instance only)
	
	public static int add(int num1, int num2) {
		
		//System.out.println("SNum1 " + snum1);
		return num1 + num2;
	}
	
	//static block is always executed first and in a sequence..usually they are used for db connections
	static {
		System.out.println(" Hey i am first static block ");
	}
	
	static {
		System.out.println(" Hey i am second static block ");
	}
	public static void main(String[] args) {
		
		
		int res =add(10, 20);
		System.out.println("Result " +res);
		
	}
	
	static {
		System.out.println(" Hey i am thrid static block ");
	}

}
