package com.fannie.day3;

public class Device implements Comparable <Device>{
	private int dId;
	private String dName;
	private double price;
	
	@Override
	public boolean equals(Object arg0) {
		Device device = (Device) arg0;
		
		return
				this.dId == device.dId &&
				this.dName.equals(device.dName) &&
				this.price == device.price;
	}
		
//		if(this.dId== device.dId && this.dName.equals(device.dName) && this.price== device.price){
//			return true;
//			
//		}else{
//			return false;
//		}
	//}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.dName.charAt(0);
	}

	@Override
	public String toString() {
		return "Device [dId=" + dId + ", dName=" + dName + ", price=" + price + "]";
	}
	
	
	public Device(){}
	
	public Device(int dId, String dName, double price) {
		super();
		this.dId = dId;
		this.dName = dName;
		this.price = price;
	}


	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public int compareTo(Device o) {
		return this.dId - o.dId;
	}

}
