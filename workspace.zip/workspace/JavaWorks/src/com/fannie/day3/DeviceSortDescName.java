package com.fannie.day3;

import java.util.Comparator;

public class DeviceSortDescName implements Comparator<Device> {
	public int compare(Device o1, Device o2) {
		return o2.getdName().compareTo(o1.getdName());
	}

	public static Comparator<Device> sortDescOnName() {
		return new Comparator<Device>() {

			public int compare(Device o1, Device o2) {

				return o2.getdName().compareTo(o1.getdName());
			}
		};
	}
}
