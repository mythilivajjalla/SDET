package com.fannie.day3;

//ctrl shift o manages all the imports
import java.io.File;

public class GetFiles {
	public static void main(String[] args) {
		File f = new File("fannie");
		
		File files [] = f.listFiles();
		for(File temp : files){
			if temp.getName()== "*.txt"
			System.out.println(temp.getName());
		}
	}

}
