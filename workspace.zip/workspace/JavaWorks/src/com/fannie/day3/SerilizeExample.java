package com.fannie.day3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.fannie.day2.Person;

public class SerilizeExample {

	public static void storeObject(Person per) {

		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("person.ser"));

			oos.writeObject(per);
			oos.writeObject(new String("Fannie"));
			oos.writeDouble

			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Saved successfully...");
	}

	public static void readObject() throws FileNotFoundException, IOException, ClassNotFoundException{
		ObjectInputStream ois =
				new ObjectInputStream(new FileInputStream ("person.ser"));
	Person person = (Person) ois.readObject();
	System.out.println(person);
	}
	
	
	public static void main(String[] args) {

	//	Person p = new Person(101, "Becky", 1212);
		//storeObject(p);

		try {
			readObject();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
