package com.fannie.day3;

import java.util.HashSet;
import java.util.Set;

public class SetEx1 {
	public static void main(String[] args) {
	Set<String> set = new HashSet<String>();
	
	set.add("Lisa");
	set.add("Mythili");
	set.add("Abdul");
	set.add("Abdul");
	set.add("Abdul");
	set.add("Abdul");
			
	System.out.println(set);
		
		
	}

}
