package com.fannie.day3;

import java.util.Set;
import java.util.TreeSet;

public class SetEx3 {
	
	public static void main(String[] args) {
		Set<String> set = new TreeSet<String>();
		
		set.add("Deepthi");
		set.add("Kawsar");
		set.add("Sashi");
		set.add("Aawsar");
		
		System.out.println(set);
	}

}
