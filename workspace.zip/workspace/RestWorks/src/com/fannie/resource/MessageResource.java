package com.fannie.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;

import com.fannie.beans.Message;
import com.fannie.service.MessageService;

@Path("/message")
public class MessageResource {
	static MessageService messageService = new MessageService();
	
	//get All Messages
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Message> getMessages(){
		return messageService.getAllMessages();
	}
	//get Message
	@GET
	@Path("/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Message getMessage(@PathParam("messageId") long messageId){
		return messageService.getMessage(messageId);
		
	}
	
	//add Message
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Message postMessage(Message message){
		System.out.println("insert called..");
		return messageService.insertMessage(message);
		
	}
	//update Message
	//delete Message
	
	@DELETE
	@Path("/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteMessage(@PathParam("messageId") long messageId)
	   throws JSONException{
		String message = messageService.deleteMessage(messageId);
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", message);
		return Response.status(200).entity(jsonObject.toString()).build();
		
	}
	
	
	

}
