package com.fannie.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test01 {
	public static void main(String[] args) {
		// Load the driver

		WebDriver driver;
		// if this doesnt work then use the second option
		// System.setProperty("webdriver.gecko.driver",
		//System.setProperty("webdriver.firefox.marionette",
//				"C:\\Software\\SDET5SeleniumSoftware\\selenium-java-3.4.0\\driver\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		//if it is internet explorer
			//	 webdriver.ie.driver
		System.setProperty("webdriver.chrome.driver", "C:\\Software\\SDET5SeleniumSoftware\\selenium-java-3.4.0\\driver\\chromedriver.exe");

		//driver = new FirefoxDriver();
		 driver = new ChromeDriver();
		// open the browser for the driver
		String baseUrl = "http://google.com";
		driver.get(baseUrl);

		// do the task
		System.out.println("Title   -> " + driver.getTitle());

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// close the browser

		driver.close();
	}

}
