package com.fannie.utility;

public interface Driver {
	
	String CHROME = "webdriver.chrome.driver";
	String FIREFOX = "webdriver.gecko.driver";
	String IE = "webdriver.ie.driver";
	String PHANTOM="";
	
	//PATH  
	
	String CHROME_PATH= "C:\\Software\\SDET5SeleniumSoftware\\selenium-java-3.4.0\\driver\\chromedriver.exe";
	String FIREFOX_PATH= "C:\\Software\\SDET5SeleniumSoftware\\selenium-java-3.4.0\\driver\\geckodriver-v0.16.1-win64\\geckodriver.exe";

}
