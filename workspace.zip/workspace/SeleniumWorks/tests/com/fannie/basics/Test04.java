package com.fannie.basics;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fannie.utility.Driver;

public class Test04 {

	WebDriver driver;
	String baseURL;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
	}

	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();	
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 driver.manage().window().maximize();
		baseURL = "http://naveenks.com/selenium/RegForm.html";
		driver.get(baseURL);
	}

	@After
	public void tearDown() throws Exception {
		
		Thread.sleep(3000);
		driver.quit();
	}


	@Test
	public void test() throws Exception {

		
		WebElement male = driver.findElement(By.linkText("genderMale"));
		male.click();
		
		Thread.sleep(2000);
		
		
		WebElement female = driver.findElement(By.linkText("female"));
		female.click();
		
		System.out.println("Male selected ->" + male.isSelected());
		
		Thread.sleep(2000);
		
		WebElement transgender = driver.findElement(By.linkText("transgender"));
		transgender.click();
		
		Thread.sleep(2000);
		
		System.out.println("Male selected ->" + male.isSelected());
		System.out.println("FeMale selected ->" + female.isSelected());
		System.out.println("Trans selected ->" + transgender.isSelected());
		
	}

}
