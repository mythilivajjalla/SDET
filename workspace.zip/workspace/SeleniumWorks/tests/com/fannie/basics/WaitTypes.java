package com.fannie.basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitTypes {

	private WebDriver driver;

	public WaitTypes(WebDriver driver) {

		this.driver = driver;

	}

	
	//presend of element located
	public WebElement presenceElementLocated(By locator, int timeout) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeout);

			WebElement element = wait.until(

					ExpectedConditions.presenceOfElementLocated(locator));

			System.out.println("Element Located");

			return element;
		} catch (Exception e) {

			System.out.println("Element not locate " + e);

		}
		return null;

	}

	public WebElement waitForElement(By locator, int timeout) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeout);

			WebElement element = wait.until(

					ExpectedConditions.visibilityOfElementLocated(locator));

			System.out.println("Element Located");

			return element;
		} catch (Exception e) {

			System.out.println("Element not locate " + e);

		}
		return null;

	}

}
