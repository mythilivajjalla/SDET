package com.fannie;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style=Style.RPC)

public interface ICreditScoreCheck {
	@WebMethod
	public String sayHi(@WebParam(name="userName") String name);
	
	//public String sayHi(String name , name);
	
	@WebMethod
	public String checkCreditScore(String name, int score);
	  
	@WebMethod
	public boolean checkEligible(int score);
	

}
